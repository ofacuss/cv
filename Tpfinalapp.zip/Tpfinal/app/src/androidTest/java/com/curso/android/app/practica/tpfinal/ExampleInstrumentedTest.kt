package com.curso.android.app.practica.tpfinal

import androidx.test.espresso.Espresso.closeSoftKeyboard
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.ViewAction
import androidx.test.espresso.ViewInteraction
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.action.ViewActions.typeText
import androidx.test.espresso.matcher.ViewMatchers.withId
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith

private fun ViewInteraction.perform(typeText: ViewAction?, closeSoftKeyboard: Unit) {

}

/**
 * Instrumented test, which will execute on an Android device.
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
@RunWith(AndroidJUnit4::class)
class ExampleInstrumentedTest {
    @Test
    fun useAppContext() {

        val appContext = InstrumentationRegistry.getInstrumentation().targetContext
        assertEquals("com.curso.android.app.practica.tpfinal", appContext.packageName)
    }
    fun probartexto() {

        onView(withId(R.id.texto1))
            .perform(typeText("Hola mundo"), closeSoftKeyboard())
        onView(withId(R.id.boton)).perform(click())



    }
}