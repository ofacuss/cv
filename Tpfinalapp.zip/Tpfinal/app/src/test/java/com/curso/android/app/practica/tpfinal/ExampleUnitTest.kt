package com.curso.android.app.practica.tpfinal

import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
class ExampleUnitTest {
    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }
}
class UnitTest {
    @Test
    fun comparacion_iguales () {

        val text1 = "casa"
        val text2 = "casa"


        if (text1 == text2) {
            print("iguales")
        } else {
            print("diferentes")
        }


    }
}