package com.curso.android.app.practica.tpfinal

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.text.Collator

class MainActivity : AppCompatActivity() {



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val boton: Button = findViewById(R.id.boton)
        val visor: TextView = findViewById(R.id.visor)
        val texto1: EditText = findViewById(R.id.texto1)
        val texto2: EditText = findViewById(R.id.texto2)

        boton.setOnClickListener {



            val text1 = texto1.text.toString()
            val text2 = texto2.text.toString()

            if (text1 == text2) {
                visor.text = "Iguales"
            } else
                visor.text = "Diferentes"


        }
    }
}


